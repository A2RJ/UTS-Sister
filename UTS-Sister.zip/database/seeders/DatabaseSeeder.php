<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        $this->call([
            HumanResourcesTableSeeder::class,
            StructuresTableSeeder::class,
            FacultiesTableSeeder::class,
            StudyProgramsTableSeeder::class,
        ]);
        $this->call(ClassesTableSeeder::class);
        $this->call(SubjectsTableSeeder::class);
        $this->call(MeetingsTableSeeder::class);
    }
}
