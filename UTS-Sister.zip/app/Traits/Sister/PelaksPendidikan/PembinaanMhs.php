<?php

namespace App\Traits\Sister\PelaksPendidikan;

trait PembinaanMhs
{
}
