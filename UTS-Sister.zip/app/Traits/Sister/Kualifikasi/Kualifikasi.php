<?php

namespace App\Traits\Sister\Kualifikasi;

trait Kualifikasi
{
    use PendidikanFormal, Diklat, RiwayatPekerjaan;
}
