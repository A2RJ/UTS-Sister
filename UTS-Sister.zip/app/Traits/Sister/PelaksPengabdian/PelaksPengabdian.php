<?php

namespace App\Traits\Sister\PelaksPengabdian;

trait PelaksPengabdian
{
    use Pengabdian,
        PengelolaJurnal,
        Pembicara,
        JabatanStruktural;
}
