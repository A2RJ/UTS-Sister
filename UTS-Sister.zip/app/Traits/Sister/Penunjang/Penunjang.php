<?php

namespace App\Traits\Sister\Penunjang;

trait Penunjang
{
    use
        //  AnggotaProfesiTriDharma,
        // PenghargaanTriDharma,
        AnggotaProfesi,
        Penghargaan,
        PenunjangLain;
}
