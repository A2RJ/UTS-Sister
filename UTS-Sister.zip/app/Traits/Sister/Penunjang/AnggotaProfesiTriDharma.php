<?php

namespace App\Traits\Sister\Penunjang;

trait AnggotaProfesiTriDharma
{
}
