{
    /* <button onclick="copyText()">Copy</button>

<script>
  function copyText() {
    // Ambil element yang ingin disalin
    var copyText = document.getElementById("textToCopy");

    // Pilih teksnya
    copyText.select();

    // Salin teksnya
    document.execCommand("copy");

    // Tampilkan pesan sukses
    alert("Text has been copied to clipboard");
  }
</script>
<p id="textToCopy">This is the text to copy</p>
<textarea id="textToCopy">This is the text to copy</textarea>
<input type="text" id="textToCopy" value="This is the text to copy"> */
}
