<?php

namespace App\Traits\Sister\PelaksPenelitian;

trait PelaksPenelitian
{
    use Penelitian,
        PublikasiKarya,
        PatenHKI;
}
