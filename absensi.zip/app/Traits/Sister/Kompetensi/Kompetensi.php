<?php

namespace App\Traits\Sister\Kompetensi;

trait Kompetensi
{
    use SertifikasiProfesi, SertifikasiDosen, Tes;
}
