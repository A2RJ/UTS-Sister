<?php

namespace App\Traits\Sister\Profil;

trait Profil
{
    use DataPribadi, Inpassing, Japung, Kepangkatan, Penugasan;
}
