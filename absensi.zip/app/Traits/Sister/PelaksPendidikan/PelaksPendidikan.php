<?php

namespace App\Traits\Sister\PelaksPendidikan;

trait PelaksPendidikan
{
    use Pengajaran,
        BimbinganMhs,
        PengujianMhs,
        VisitingScientist,
        PembinaanMhs,
        BahanAjar,
        Detasering,
        OrasiIlmiah,
        PembimbingDosen,
        TugasTambahan;
}
